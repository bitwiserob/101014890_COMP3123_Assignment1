# 101014890_COMP3123_Assignment1

## Project was generated with jetbrain webstorm because i like switching editors every 5 mintues
## it stores setting and runs the server from bin/www when using npm start also the port is 3000

### account to login is username: admin, password admin
## TODO

* user routes
* validation

## Done


* Models
* employee routes



